import time
import json
from typing import cast, Iterable
from pathlib import Path

from reducto import Reducto
from reducto.types import ExtractResponse, ParseResponse, SplitCategory, SplitResponse
from reducto.types.job_get_response import Result

from .client import ExtractionClient
from sema4ai_docint.logging import logger

class SyncExtractionClient(ExtractionClient):
    """Synchronous Client for extracting documents using Reducto.
    
    This implementation uses the synchronous Reducto client to upload and process documents. However, we use their
    Job API to poll for job completion rather than blocking on the HTTP calls.
    """
    
    def __init__(self, api_key: str, base_url: str | None = None, disable_ssl_verification: bool = False):
        """Initialize the Reducto client.
        
        Args:
            api_key: Sema4.ai API key.
        """
        if not base_url:
            base_url = super().SEMA4_REDUCTO_ENDPOINT

        self._client = SyncExtractionClient._new_reducto_client(api_key, base_url=base_url, disable_ssl_verification=disable_ssl_verification)
        self.base_url = base_url
        self.disable_ssl_verification = disable_ssl_verification
    
    def upload(self, document_path: Path) -> str:
        """Upload a document to Reducto.
        
        Args:
            document_path: Path to the document on the local filesystem.
        
        Returns:
            The file ID of the uploaded document.
        """
        # Nb. Previous, we would upload direct to Reducto if it was less than 8MB.
        # However, the backend.sema4.ai API Gateway is mangling the Content-Type (or similar).
        # Now, force the presigned-url regardless of the file size to avoid this.

        # use the presigned url to upload the file
        upload_resp = self.client._client.post(
            f"{self.base_url}/upload",
            headers=self.client._client.headers,
        )

        # raise a well-formed exception if the upload failed with http/403
        if upload_resp.status_code == 403:
            logger.error(f"File upload failed with http/403: {upload_resp}")
            raise Exception("File upload failed with http/403: Please check your Sema4.ai API key and try again.")

        # raise an exception if the upload failed for any other reason
        upload_resp.raise_for_status()

        resp = upload_resp.json()
        # make sure the upload response has the expected fields
        if "presigned_url" not in resp:
            logger.error(f"File upload failed: No presigned URL returned. Response: {upload_resp}")
            raise Exception("File upload failed: No presigned URL returned.")
        if "file_id" not in resp:
            logger.error(f"File upload failed: No file ID returned. Response: {upload_resp}")
            raise Exception("File upload failed: No file ID returned.")

        # put the file to the presigned url (ensure Content-Length is provided to avoid chunked upload)
        put_resp = self.client._client.put(
            resp["presigned_url"],
            content=open(document_path, "rb"),
        )
        put_resp.raise_for_status()

        # Return the file_id
        return resp["file_id"]
    
    def unwrap(self) -> Reducto:
        """Return the underlying Reducto client.
        
        Returns:
            The underlying Reducto client.
        """
        return self._client
    
    def parse(self, document_id: str, config: dict | None = None) -> ParseResponse:
        """Parse a document using Reducto.
        
        Args:
            document_id: The Reducto file ID of the document to parse.
            config: Optional configuration to override default parse settings
        
        Returns:
            The parse response from Reducto.
        """
        opts = self.parse_opts(config)

        # log a note about the Reducto extraction configuration we're using
        if opts:
            import pprint
            logger.info(f"Parse config: {pprint.pformat(opts, indent=2)}")

        job_resp = self.client.parse.run_job(
            document_url=document_id,
            **opts,
        )
        
        resp = self._complete(job_resp.job_id)
        parsed_resp = cast(ParseResponse, resp)
        return ExtractionClient.localize_parse_response(parsed_resp)
    
    def split(self, document_id: str, split_description: Iterable[SplitCategory], split_rules: str | None = None, config: dict | None = None) -> SplitResponse:
        """Split a document using Reducto.
        
        Args:
            document_id: The Reducto file ID of the document to split.
            split_description: The description of the split to perform.
            split_rules: Optional split rules to use.
            config: Optional configuration to override default split settings
        
        Returns:
        """
        # Default options
        opts = self.split_opts(config)

        # Set split_descriptions
        opts["split_description"] = list(split_description)
        # Optionally set split_rules
        if split_rules:
            opts["split_rules"] = split_rules

        # log a note about the Reducto split configuration we're using
        if opts:
            import pprint
            logger.info(f"Split config: {pprint.pformat(opts, indent=2)}")
        
        job_resp = self.client.split.run_job(
            document_url=document_id,
            **opts,
        )

        resp = self._complete(job_resp.job_id)
        return cast(SplitResponse, resp)


    def extract(self, document_id: str, schema: dict, system_prompt: str | None = None, start_page: int | None = None, end_page: int | None = None, extraction_config: dict | None = None) -> ExtractResponse:
        """Extract data from a document using Reducto.
        
        Args:
            document_id: The Reducto file ID of the document to extract data from.
            schema: The JSON schema for extraction
            system_prompt: Optional custom system prompt for extraction
            start_page: Optional start page for extraction
            end_page: Optional end page for extraction
            extraction_config: Optional configuration to override default extraction settings
        
        Returns:
            The extraction response from Reducto.
        """
        # leave a hint about the extraction system prompt in-use
        if system_prompt:
            logger.info(f"using custom prompt for extraction: '{system_prompt}'")
        else:
            logger.info("using standard prompt for extraction")

        opts = self.extract_opts(
            schema,
            (ExtractionClient.DEFAULT_EXTRACT_SYSTEM_PROMPT if system_prompt is None else system_prompt),
            start_page=start_page,
            end_page=end_page,
            extraction_config=extraction_config,
        )

        # log a note about the Reducto extraction configuration we're using
        if opts:
            import pprint
            logger.info(f"Extraction config: {pprint.pformat(opts, indent=2)}")

        job_resp = self.client.extract.run_job(
            document_url=document_id,
            **opts,
        )

        resp = self._complete(job_resp.job_id)
        return cast(ExtractResponse, resp)

    # reducto's Result type appears to not be exported for us to use.
    def _complete(self, job_id: str) -> Result:
        while True:
            job_resp = self.client.job.get(
                job_id=job_id,
            )
            match job_resp.status:
                case "Completed":
                    return job_resp.result
                case "Failed":
                    raise Exception(f"Extract job failed: {job_resp.reason}")
                case "Pending":
                    time.sleep(3)
                case "Idle":
                    time.sleep(3)
                case _:
                    raise Exception(f"Unknown job status: {job_resp.status}")
