"""
Main client implementation for doc-extraction.
"""

from abc import ABC, abstractmethod
from itertools import chain
import json
from pathlib import Path
from typing import Iterable
import httpx
import sema4ai_http
from ssl import SSLContext

from reducto import Reducto
from reducto.types import ExtractResponse, ParseResponse, SplitCategory, SplitResponse
from reducto.types.shared.parse_response import ResultFullResult

from sema4ai_docint.logging import logger


class ExtractionClient(ABC):
    """Main client for document-extraction."""

    SEMA4_REDUCTO_ENDPOINT = "https://backend.sema4.ai/reducto"
    DEFAULT_EXTRACT_SYSTEM_PROMPT = "Be precise and thorough. Mark required, missing fields as null. Omit optional fields."

    _extract_only_keys = ["schema", "system_prompt", "generate_citations", "array_extract", "use_chunking", "include_images", "spreadsheet_agent"]

    @staticmethod
    def _make_mounts(network_config: sema4ai_http.NetworkProfile) -> dict[str, httpx.HTTPTransport | None]:
        """Make mounts for proxy configuration. Copied from sema4ai-http-helper README."""
        if not network_config.ssl_context:
            raise ValueError("SSL context missing from sema4ai-http-helper NetworkProfile")
        
        mounts: dict[str, httpx.HTTPTransport | None] = {}
        for http_proxy in chain(
            network_config.proxy_config.http, network_config.proxy_config.https
        ):
            mounts[http_proxy] = httpx.HTTPTransport(network_config.ssl_context)
        for no_proxy in network_config.proxy_config.no_proxy:
            mounts[no_proxy] = None

        return mounts

    @classmethod
    def _new_reducto_client(cls, api_key: str, base_url: str=SEMA4_REDUCTO_ENDPOINT, disable_ssl_verification: bool=False) -> Reducto:
        """Create a new Reducto client."""
        network_config = sema4ai_http.get_network_profile()
        ssl_context: SSLContext | None | bool = network_config.ssl_context
        if disable_ssl_verification:
            ssl_context = False
        elif ssl_context is None:
            raise ValueError("SSL context missing from sema4ai-http-helper NetworkProfile")

        # Set up mounts for proxy configuration
        mounts = cls._make_mounts(network_config)

        # Create httpx client with the configured mounts and SSL context
        httpx_client = httpx.Client(mounts=mounts, verify=ssl_context)

        if base_url is None:
            # Assume the api_key is a Reducto API key. We should not be using the SAAS Redacto offering in practice.
            logger.warning("No base URL provided. Using default Reducto API URL.")
            return Reducto(
                api_key=api_key,
                http_client=httpx_client,
            )

        rc = Reducto(
            api_key="unused", # We have to set a Reducto api_key here, but it's ignored in usage of the client.
            base_url=base_url,
            http_client=httpx_client,
        )
        rc._client.headers["X-API-Key"] = api_key
        return rc

    @property
    def client(self) -> Reducto:
        """Return the Reducto client."""
        return self._client

    @client.setter
    def client(self, value: Reducto):
        """Set the Reducto client."""
        if not isinstance(value, Reducto):
            raise ValueError("client must be a Reducto instance")
        self._client = value

    @abstractmethod
    def unwrap(self) -> Reducto:
        """Return the underlying Reducto client."""
        pass

    @abstractmethod
    def upload(self, document_path: Path) -> str:
        """Upload a document to the client."""
        pass

    @abstractmethod
    def parse(self, document_id: str, config: dict | None = None) -> ParseResponse:
        """Parse a document using the client."""
        pass

    @abstractmethod
    def split(self, document_id: str, split_description: Iterable[SplitCategory], split_rules: str | None = None, config: dict | None = None) -> SplitResponse:
        """Split a document using the client."""
        pass

    @abstractmethod
    def extract(self, document_url: str, schema: dict, system_prompt: str | None = None, start_page: int | None = None, end_page: int | None = None, extraction_config: dict | None = None) -> ExtractResponse:
        """Extract data from a document using the client."""
        pass

    def split_opts(self, config: dict | None = None) -> dict:
        """
        Constructs the default split options for Reducto, applying any overrides to the default configuration.
        """
        default_config = ExtractionClient._default_parse_opts()

        # Merge with provided configuration if available
        if config:
            return ExtractionClient.merge_config(default_config, config)

        return default_config
    
    @classmethod
    def _default_parse_opts(cls) -> dict:
        """
        Default parse options for Reducto.

        These options are shared across both parse and extract. Changes to this default option must
        be made with extreme care as they will affect the accuracy of extraction.
        """

        return {
            "options": {
                "extraction_mode": "ocr",
                "ocr_mode": "standard",
                "chunking": {
                    "chunk_mode": "disabled"
                },
                "table_summary": {
                    "enabled": False
                },
                "figure_summary": {
                    "enabled": False
                },
                "filter_blocks": [
                    "Page Number",
                    "Header",
                    "Footer",
                    "Comment"
                ],
                "force_url_result": False
            },
            "advanced_options": {
                "ocr_system": "highres",
                "table_output_format": "html",
                "merge_tables": False,
                "continue_hierarchy": True,
                "keep_line_breaks": False,
                "page_range": {
                    "start": None,
                    "end": None
                },
                "large_table_chunking": {
                    "enabled": True,
                    "size": 50
                },
                "spreadsheet_table_clustering": "default",
                "remove_text_formatting": False,
                "filter_line_numbers": False,
            },
            "experimental_options": {
                "enrich": {
                    "enabled": False,
                    "mode": "standard"
                },
                "native_office_conversion": False,
                "enable_checkboxes": False,
                "rotate_pages": False,
                "enable_underlines": False,
                "enable_equations": False,
                "return_figure_images": False,
                "layout_enrichment": False,
                "layout_model": "default"
            },
            "timeout": 300,
        }

    def parse_opts(self, config: dict | None = None) -> dict:
        default_config = ExtractionClient._default_parse_opts()

        # Merge with provided configuration if available
        if config:
            # Some options are only valid for extract, not parse. We filter them out here.
            filtered_config = {k: v for k, v in config.items() if k not in ExtractionClient._extract_only_keys}
            return ExtractionClient.merge_config(default_config, filtered_config)

        return default_config

    
    def extract_opts(self, schema: dict, system_prompt: str, start_page: int | None = None, end_page: int | None = None, extraction_config: dict | None = None) -> dict:
        default_config = ExtractionClient._default_parse_opts()
        # Merge in the extraction configuration with the default parse option
        default_config = ExtractionClient.merge_config(default_config, {
            "schema": schema,
            "advanced_options": {
                "page_range": {
                    "start": start_page,
                    "end": end_page,
                },
            },
            "array_extract": {
                "enabled": False,
                # Let the mode default to legacy, don't set it to streaming
            },
            "system_prompt": system_prompt,
            "generate_citations": False,
            "timeout": 300,
        })

        # Merge with provided extraction configuration if available
        if extraction_config:
            return ExtractionClient.merge_config(default_config, extraction_config)
        
        return default_config

    @classmethod
    def _has_top_level_array(cls, schema: dict) -> bool:
        """Check if the schema has a top-level property which is an array."""
        if "properties" in schema:
            for k, v in schema["properties"].items():
                if "type" in v and v["type"] == "array":
                    return True
        return False

    @classmethod
    def merge_config(cls, default_config: dict, user_config: dict | None) -> dict:
        """
        Merge user configuration with default configuration.

        Args:
            default_config: The default configuration from code
            user_config: The configuration from user (can be None)

        Returns:
            Merged configuration with database config overriding default config
        """
        if not user_config:
            return default_config

        def deep_merge(base: dict, override: dict) -> dict:
            """Recursively merge two dictionaries, with override taking precedence."""
            result = base.copy()
            for key, value in override.items():
                # Special handling for fields that should be completely replaced, not merged
                if key in ["schema", "system_prompt"]:
                    result[key] = value
                elif key in result and isinstance(result[key], dict) and isinstance(value, dict):
                    result[key] = deep_merge(result[key], value)
                else:
                    result[key] = value
            return result

        return deep_merge(default_config, user_config)

    @classmethod
    def localize_parse_response(cls, resp: ParseResponse) -> ParseResponse:
        """
        Conditionally fetch the remote results from a ResultURLResult in this ParseResponse.

        Args:
            resp: The ParseResponse to localize

        Returns:
            The parsed result as a ResultFullResult object
        """
        # Nothing to do, we have the full result
        if resp.result.type != "url":
            return resp

        try:
            response = sema4ai_http.get(resp.result.url)
            response.raise_for_status()  # Raise an exception for bad status codes
            result_dict = response.json()

            # Convert the dictionary to a ResultFullResult object
            resp.result = ResultFullResult(**result_dict)
            return resp
        except Exception as e:
            logger.error(f"Error fetching result from URL: {str(e)}")
            raise e
