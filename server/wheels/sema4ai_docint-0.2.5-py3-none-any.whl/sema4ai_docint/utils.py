import re


def normalize_name(name: str) -> str:
    """Normalize name by removing special characters, replacing spaces with underscores,
    and converting to lowercase.

    Args:
        name: The name to normalize

    Returns:
        The normalized name
    """
    # Remove special characters (keep only alphanumerics and spaces)
    cleaned = re.sub(r"[^\w\s]", "", name.strip())

    # Replace spaces with underscores and convert to lowercase
    return "_".join(cleaned.split()).lower()
