"""
Document service for high-level document operations.
"""

from typing import Any

from sema4ai.actions.chat import get_file

from sema4ai_docint.extraction.process import (
    ExtractAndTransformContentParams,
    ExtractionSchema,
    TranslationSchema,
    validate_and_parse_schemas,
)
from sema4ai_docint.extraction.reducto.config import ReductoConfig
from sema4ai_docint.extraction.transform import transform_content
from sema4ai_docint.extraction.transform.transform_document_layout import (
    TransformDocumentLayout,
)
from sema4ai_docint.logging import logger
from sema4ai_docint.utils import normalize_name
from sema4ai_docint.validation.models import ValidationRule
from sema4ai_docint.validation.validate import validate_document_extraction

from ..models import DataModel, Document, DocumentLayout, initialize_dataserver
from ..models.constants import PROJECT_NAME
from ._context import _DIContext
from .exceptions import DocumentServiceError


class _DocumentService:
    def __init__(self, context: _DIContext) -> None:
        self._context = context

    def query(self, document_id: str) -> dict[str, Any]:
        """Get document in data model format.

        Args:
            document_id: Document ID to retrieve

        Returns:
            Dict with document data as dict with view names as keys

        Raises:
            DocumentServiceError: If document or data model not found
        """
        document = Document.find_by_id(self._context.datasource, document_id)
        if not document:
            raise DocumentServiceError(f"Document with ID {document_id} not found")

        data_model = DataModel.find_by_name(
            self._context.datasource, document.data_model
        )
        if not data_model:
            raise DocumentServiceError(
                f"Data model with name {document.data_model} not found"
            )

        # Collect all view names from the data model's views
        view_names = []
        if data_model.views:
            for view in data_model.views:
                if isinstance(view, dict) and "name" in view:
                    view_names.append(view["name"])

        if not view_names:
            raise DocumentServiceError(
                f"No views found for data model {document.data_model}"
            )

        # Initialize the objects in MindsDB (project)
        try:
            initialize_dataserver(PROJECT_NAME, data_model.views)
        except Exception as e:
            raise DocumentServiceError(
                "Failed to create the document intelligence data-server project"
            ) from e

        # Loop over all view names and collect results
        results_dict = {}
        for view_name in view_names:
            sql = f"SELECT * FROM {PROJECT_NAME}.{view_name} where document_id = $document_id"

            results = self._context.datasource.execute_sql(
                sql, params={"document_id": document_id}
            )
            if results:
                results_dict[view_name] = results.to_table()
            else:
                results_dict[view_name] = None

        return results_dict

    def ingest(
        self,
        file_name: str,
        data_model_name: str,
        layout_name: str,
    ) -> dict[str, Any]:
        """Ingest document into data model using layout.

        This function creates PERSISTENT state by storing the document, extracted content,
        and transformed content in the database.

        Args:
            file_name: PDF file name to process
            data_model_name: Data model name for document
            layout_name: Document layout to use for processing

        Returns:
            Dict with created document containing extracted and transformed content

        Raises:
            DocumentServiceError: If document processing fails
        """
        data_model_name = normalize_name(data_model_name)
        layout_name = normalize_name(layout_name)

        try:
            data_model = DataModel.find_by_name(
                self._context.datasource, data_model_name
            )
            if not data_model:
                raise DocumentServiceError(f"Data model {data_model_name} not found")

            layout = DocumentLayout.find_by_name(
                self._context.datasource, data_model_name, layout_name
            )
            if not layout:
                raise DocumentServiceError(
                    f"Document layout does not exist: {layout_name}"
                )

            if not layout.extraction_schema:
                raise DocumentServiceError(
                    f"Layout {layout_name} has no extraction schema"
                )
            if not layout.translation_schema:
                raise DocumentServiceError(
                    f"Layout {layout_name} has no translation schema"
                )

            parsed_extraction_schema, parsed_translation_schema = (
                validate_and_parse_schemas(
                    layout.extraction_schema, layout.translation_schema
                )
            )

            return self._process_with_validation_and_retry(
                file_name=file_name,
                data_model_name=data_model_name,
                layout_name=layout_name,
                parsed_extraction_schema=parsed_extraction_schema,
                parsed_translation_schema=parsed_translation_schema,
                data_model_prompt=data_model.prompt,
                extraction_config=layout.extraction_config,
                layout_prompt=layout.system_prompt,
                success_layout_update_type="ingest_success",
                retry_success_layout_update_type="ingest_retry_success",
            )

        except Exception as e:
            raise DocumentServiceError(f"Failed to process document: {str(e)}") from e

    def extract_with_schema(
        self,
        params: ExtractAndTransformContentParams,
    ) -> dict[str, Any]:
        """Extract, transform, validate content with automatic retry and schema storage.

        This function performs the complete document processing pipeline:
        1. Extract and transform content using provided schemas
        2. Validate the processed document
        3. If validation fails, automatically retry with different configurations
        4. Store successful schemas in database for future use

        Args:
            sema4_api_key: Sema4.ai cloud backend API key
            params: ExtractAndTransformContentParams object containing:
                - file_name: file name to process
                - extraction_schema: Extraction schema as JSON string (must be valid JSON)
                - translation_schema: Translation schema as dict with "rules" key containing array of mapping rules
                - data_model_name: Data model name for document
                - layout_name: Document layout to use for processing
            datasource: Document intelligence data source connection

        Returns:
            Response with created document containing extracted and transformed content,
            validation results, and retry information if applicable.

        Raises:
            DocumentServiceError: If document processing fails after all retry attempts
        """

        data_model = DataModel.find_by_name(
            self._context.datasource, params.data_model_name
        )
        if not data_model:
            raise DocumentServiceError(f"Data model {params.data_model_name} not found")

        # Validate and parse schemas
        parsed_extraction_schema, parsed_translation_schema = (
            validate_and_parse_schemas(
                params.extraction_schema, params.translation_schema
            )
        )

        return self._process_with_validation_and_retry(
            file_name=params.file_name,
            data_model_name=params.data_model_name,
            layout_name=params.layout_name,
            parsed_extraction_schema=parsed_extraction_schema,
            parsed_translation_schema=parsed_translation_schema,
            data_model_prompt=data_model.prompt,
            extraction_config=None,
            layout_prompt=None,
            success_layout_update_type="default_success",
            retry_success_layout_update_type="retry_success",
        )

    def validate(self, data_model_name: str, document_id: str) -> dict[str, Any]:
        """Validate a document against quality checks.

        Args:
            data_model_name: The name of the data model
            document_id: The ID of the document to validate
            datasource: The document intelligence data source connection

        Returns:
            Response containing validation results with overall status and rule outcomes

        Raises:
            DocumentServiceError: If data model not found, no quality checks exist, project creation fails, or validation fails
        """
        data_model_name = normalize_name(data_model_name)
        data_model = DataModel.find_by_name(self._context.datasource, data_model_name)
        if not data_model:
            raise DocumentServiceError(
                f"Data model with name {data_model_name} not found"
            )

        if not data_model.quality_checks:
            raise DocumentServiceError(
                f"No quality checks found for data model {data_model_name}"
            )

        # Initialize the objects in MindsDB (project)
        try:
            initialize_dataserver(PROJECT_NAME, data_model.views)
        except Exception as e:
            raise DocumentServiceError(
                "Failed to create the document intelligence data-server project"
            ) from e

        # Parse quality checks - all stored rules should be valid
        quality_checks = [ValidationRule(**rule) for rule in data_model.quality_checks]

        validation_summary = validate_document_extraction(
            document_id, self._context.datasource, quality_checks
        )

        if validation_summary.overall_status == "failed":
            raise DocumentServiceError(
                f"Document validation encountered errors: {validation_summary.model_dump()}"
            )
        return validation_summary.model_dump()

    def _process_document_with_schemas(
        self,
        file_name: str,
        data_model_name: str,
        layout_name: str,
        extraction_schema: ExtractionSchema,
        translation_schema: TranslationSchema,
        user_prompt: str | None = None,
        extraction_config: dict[str, Any] | None = None,
        layout_prompt: str | None = None,
    ) -> Document:
        """Helper function to process document with extraction and translation schemas.

        Args:
            file_name: Name of the file
            data_model_name: Data model name for document
            layout_name: Document layout name
            extraction_schema: Parsed extraction schema
            translation_schema: Parsed translation schema
            user_prompt: Optional user prompt for processing
            extraction_config: Optional Reducto extraction configuration
            layout_prompt: Optional layout prompt

        Returns:
            Processed document instance

        Raises:
            DocumentServiceError: If document processing fails
        """
        try:
            # Generate document ID
            pdf_path = get_file(file_name)

            transformer = TransformDocumentLayout()
            document_id = transformer.get_doc_uuid(pdf_path)
            logger.info(f"Generated document ID: {document_id}")

            # Check if document already exists
            document = Document.find_by_id(self._context.datasource, document_id)
            if not document:
                # Create new document
                document = Document(
                    id=document_id,
                    document_name=file_name,
                    data_model=data_model_name,
                    document_layout=layout_name,
                )
                document.insert(self._context.datasource)
            else:
                # Update existing document
                document.document_layout = layout_name
                document.data_model = data_model_name
                document.document_name = file_name
                document.update(self._context.datasource)

            # Extract content using Reducto
            extracted_content = self._context.extraction_service.extract(
                pdf_path,
                extraction_schema,
                user_prompt,
                extraction_config,
                layout_prompt,
            )
            logger.info("Content extracted successfully")

            # Update document with extracted content
            document.extracted_content = extracted_content
            document.update(self._context.datasource)

            # Transform content using translation schema
            transformed_content = transform_content(
                transformer, extracted_content, translation_schema
            )

            # Check if transformed content is empty
            if not transformed_content:
                raise DocumentServiceError(
                    "Transformation resulted in empty content. Please check the translation rules and extracted content."
                )

            logger.info("Content transformed successfully")

            # Update document with transformed content
            document.translated_content = transformed_content
            document.update(self._context.datasource)

            return document

        except Exception as e:
            logger.error(f"Error in document processing: {str(e)}")
            raise DocumentServiceError(f"Document processing failed: {str(e)}") from e

    def _validate_and_store_schemas(
        self,
        document: Document,
        parsed_extraction_schema: dict[str, Any],
        parsed_translation_schema: dict[str, Any],
        config_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Validate document and store schemas on success.

        Args:
            document: Document to validate
            datasource: Data source connection
            parsed_extraction_schema: Parsed extraction schema
            parsed_translation_schema: Parsed translation schema
            config_data: Optional config data for retry scenarios

        Returns:
            Dict with validation results

        Raises:
            DocumentServiceError: If validation fails
        """
        # Attempt validation
        validation_response = self.validate(document.data_model, document.id)

        # Validation passed - store schemas
        DocumentLayout.upsert_schema(
            self._context.datasource,
            document.data_model,
            document.document_layout,
            parsed_extraction_schema,
            parsed_translation_schema,
            config_data,
        )

        return validation_response

    def _retry_extraction_with_configs(
        self,
        file_name: str,
        parsed_extraction_schema: dict[str, Any],
        parsed_translation_schema: dict[str, Any],
        original_document: Document,
        data_model_prompt: str | None = None,
        initial_layout_config: dict[str, Any] | None = None,
        max_retries: int = 5,
    ) -> dict[str, Any]:
        """Retry extraction with different configurations until validation passes.

        Args:
            file_name: file name
            parsed_extraction_schema: Parsed extraction schema
            parsed_translation_schema: Parsed translation schema
            original_document: Original document that failed validation
            data_model_prompt: Optional data model prompt for processing
            initial_layout_config: Initial layout extraction config to avoid retrying
            max_retries: Maximum retry attempts

        Returns:
            Dict containing success status, retry info, validation results, and document
        """
        # Get custom configs to try
        custom_configs = ReductoConfig.load_config()

        # Filter out configs that match the initial layout config (no point retrying with same config)
        filtered_configs = {}
        for config_name, config_data in custom_configs.items():
            if initial_layout_config and _configs_are_equivalent(
                config_data, initial_layout_config
            ):
                logger.info(
                    f"Skipping config '{config_name}' as it matches the initial layout config"
                )
                continue
            filtered_configs[config_name] = config_data

        if not filtered_configs:
            raise ValueError(
                "Document processing failed validation and no different custom configs available for retry (all custom configs match the initial layout config)"
            )

        logger.info(
            f"Found {len(filtered_configs)} custom reducto configs to try (filtered from {len(custom_configs)} total configs)"
        )

        retry_info = {
            "attempts": 0,
            "successful_config_id": None,
            "successful_config_description": None,
            "failed_configs": [],
            "validation_passed": False,
            "last_validation_error": None,
        }

        # Try each custom config
        for config_name, config_data in filtered_configs.items():
            retry_info["attempts"] += 1

            if retry_info["attempts"] > max_retries:
                logger.warning(f"Reached maximum retry limit of {max_retries}")
                break

            config_id = config_name
            config_description = f"Config {config_name}"

            logger.info(
                f"Attempt {retry_info['attempts']}: Trying extraction with config {config_id} ({config_description})"
            )

            try:
                # Re-process document with this config
                retry_document = self._process_document_with_schemas(
                    file_name=file_name,
                    data_model_name=original_document.data_model,
                    layout_name=original_document.document_layout,
                    extraction_schema=parsed_extraction_schema,
                    translation_schema=parsed_translation_schema,
                    user_prompt=data_model_prompt,  # use provided data model prompt
                    extraction_config=config_data,  # extraction_config from database
                    layout_prompt=None,  # layout_prompt
                )

                # Validate the document and store schemas
                try:
                    validation_results = self._validate_and_store_schemas(
                        retry_document,
                        parsed_extraction_schema,
                        parsed_translation_schema,
                        config_data,
                    )

                    # Validation passed!
                    retry_info["validation_passed"] = True
                    retry_info["successful_config_id"] = config_id
                    retry_info["successful_config_description"] = config_description

                    logger.info(
                        f"Validation passed with config {config_id} ({config_description})"
                    )

                    return {
                        "success": True,
                        "retry_info": retry_info,
                        "validation_results": validation_results,
                        "document": retry_document,
                    }

                except ValueError as validation_error:
                    # Validation failed with this config - capture the error details
                    retry_info["failed_configs"].append(config_id)
                    retry_info["last_validation_error"] = str(validation_error)
                    logger.info(
                        f"Validation failed with config {config_id}: {validation_error}"
                    )
                    continue

            except Exception as e:
                retry_info["failed_configs"].append(config_id)
                logger.warning(
                    f"Attempt {retry_info['attempts']} failed with config {config_id}: {str(e)}"
                )
                continue

        # All configs failed - provide detailed error information
        failed_config_ids = ", ".join(map(str, retry_info["failed_configs"]))
        error_message = (
            f"Document processing failed validation after {retry_info['attempts']} retry attempts. "
            f"Tried configs: {failed_config_ids}."
        )

        # Include the last validation error details if available
        if retry_info["last_validation_error"]:
            error_message += f"\n\nLast validation error details:\n{retry_info['last_validation_error']}"

        raise DocumentServiceError(error_message)

    def _process_with_validation_and_retry(
        self,
        file_name: str,
        data_model_name: str,
        layout_name: str,
        parsed_extraction_schema: dict[str, Any],
        parsed_translation_schema: dict[str, Any],
        data_model_prompt: str | None,
        extraction_config: dict[str, Any] | None,
        layout_prompt: str | None,
        success_layout_update_type: str,
        retry_success_layout_update_type: str,
    ) -> dict[str, Any]:
        """Shared processing logic with validation and retry for both ingest and extract_with_schema.

        Args:
            file_name: Name of the file to process
            data_model_name: Data model name for document
            layout_name: Document layout name
            parsed_extraction_schema: Parsed extraction schema
            parsed_translation_schema: Parsed translation schema
            data_model_prompt: Optional data model prompt for processing
            extraction_config: Optional Reducto extraction configuration
            layout_prompt: Optional layout prompt/system prompt
            success_layout_update_type: Layout update type for successful validation
            retry_success_layout_update_type: Layout update type for successful retry

        Returns:
            Dict with document and validation info

        Raises:
            DocumentServiceError: If processing fails after all retry attempts
        """
        # Process document with schemas
        document = self._process_document_with_schemas(
            file_name=file_name,
            data_model_name=data_model_name,
            layout_name=layout_name,
            extraction_schema=parsed_extraction_schema,
            translation_schema=parsed_translation_schema,
            user_prompt=data_model_prompt,
            extraction_config=extraction_config,
            layout_prompt=layout_prompt,
        )

        # Prepare base response
        response_data = {"document": document.to_json()}

        # Always perform validation and retry logic
        try:
            # Attempt validation and store schemas
            validation_results = self._validate_and_store_schemas(
                document,
                parsed_extraction_schema,
                parsed_translation_schema,
                extraction_config,
            )

            response_data["validation_info"] = {
                "validation_passed": True,
                "retry_attempted": False,
                "validation_results": validation_results,
                "layout_updated": True,
                "layout_update_type": success_layout_update_type,
            }

        except Exception as initial_validation_error:
            # Validation failed - attempt retry with different configs
            logger.info(
                f"Initial validation failed for document {document.id}: {initial_validation_error}"
            )
            logger.info("Attempting retry with different configurations")

            retry_result = self._retry_extraction_with_configs(
                file_name,
                parsed_extraction_schema,
                parsed_translation_schema,
                document,
                data_model_prompt,
                extraction_config,
            )

            # Update response with retry success
            response_data["document"] = retry_result["document"].to_json()
            response_data["validation_info"] = {
                "validation_passed": True,
                "retry_attempted": True,
                "retry_info": retry_result["retry_info"],
                "validation_results": retry_result["validation_results"],
                "layout_updated": True,
                "layout_update_type": retry_success_layout_update_type,
            }

        return response_data

def _configs_are_equivalent(
    config1: dict[str, Any], config2: dict[str, Any]
) -> bool:
    """Compare two extraction configs to determine if they are functionally equivalent.

    Args:
        config1: First config to compare
        config2: Second config to compare

    Returns:
        True if configs are equivalent, False otherwise
    """
    # Handle None cases
    if config1 is None and config2 is None:
        return True
    if config1 is None or config2 is None:
        return False

    # Deep comparison of config dictionaries
    try:
        return config1 == config2
    except Exception:
        # Fallback to string comparison if direct comparison fails
        return str(config1) == str(config2)
