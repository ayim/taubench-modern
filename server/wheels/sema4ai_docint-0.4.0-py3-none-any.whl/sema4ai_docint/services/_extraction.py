import json
from pathlib import Path

from typing_extensions import Any, Union

from sema4ai_docint.extraction.reducto.sync import SyncExtractionClient
from sema4ai_docint.services.exceptions import ExtractionServiceError


class _ExtractionService:
    """Service meant to encapsulate more extraction clients with different capabilities and custom logic
    but also provide access to the underlying clients."""

    def __init__(self, sema4_api_key: str, disable_ssl_verification: bool = False):
        self._sema4_api_key = sema4_api_key
        self._reducto_client = SyncExtractionClient(
            api_key=sema4_api_key,
            disable_ssl_verification=disable_ssl_verification,
        )

    @property
    def reducto(self) -> SyncExtractionClient:
        """The underlying reducto client"""
        return self._reducto_client.unwrap()

    def extract(
        self,
        file_path: Path,
        extraction_schema: Union[str, dict[str, Any]],
        data_model_prompt: str | None = None,
        extraction_config: dict[str, Any] | None = None,
        document_layout_prompt: str | None = None,
    ) -> dict[str, Any]:
        """Extract data from a document"""
        try:
            # TODO the LLM sometimes wants to pass in the name of the layout rather than the actual json schema.
            # do we need to gracefully handle this?
            if isinstance(extraction_schema, str):
                parsed_schema = json.loads(extraction_schema)
            else:
                parsed_schema = extraction_schema

            return self._reducto_client.extract_content(
                file_path,
                parsed_schema,
                data_model_prompt,
                extraction_config,
                document_layout_prompt,
            )
        except Exception as e:
            raise ExtractionServiceError(f"Error extracting document: {e}") from e
