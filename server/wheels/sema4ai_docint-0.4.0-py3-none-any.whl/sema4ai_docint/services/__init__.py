"""
Service layer for document intelligence operations.

This module provides high-level business logic services that orchestrate
interactions between models, extraction, and other components.
"""

from .di_service import DIService, build_di_service
from .exceptions import (
    DataModelServiceError,
    DocumentServiceError,
    ExtractionServiceError,
    LayoutServiceError,
)

__all__ = [
    # Exceptions
    "DocumentServiceError",
    "LayoutServiceError",
    "DataModelServiceError",
    "ExtractionServiceError",
    # Services
    "DIService",
    "build_di_service",
]
