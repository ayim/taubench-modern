"""
Layout service for document layout operations.
"""

import json
from dataclasses import asdict
from typing import Any

from sema4ai_docint.logging import logger
from sema4ai_docint.models.constants import (
    DATA_SOURCE_NAME,
    DEFAULT_LAYOUT_NAME,
    PROJECT_NAME,
)
from sema4ai_docint.models.data_model import DataModel
from sema4ai_docint.models.document_layout import DocumentLayout
from sema4ai_docint.models.initialize import initialize_dataserver
from sema4ai_docint.services.exceptions import DataModelServiceError
from sema4ai_docint.utils import normalize_name
from sema4ai_docint.views.views import View, ViewGenerator, transform_business_schema

from ._context import _DIContext


class _DataModelService:
    def __init__(self, context: _DIContext) -> None:
        self._context = context

    def generate_from_file(self, file_name: str) -> dict[str, Any]:
        """Generate a data model schema from an uploaded document file.

        Args:
            file_name: The name of the file to generate a data model from

        Returns:
            Response with generated schema and success message

        Raises:
            DataModelServiceError: If schema generation fails
        """

        try:
            schema = self._context.agent_client.generate_schema_from_document(file_name)
        except Exception as e:
            raise DataModelServiceError(
                f"Failed to generate data model schema: {e}"
            ) from e

        return {"message": "Data model generated successfully", "schema": schema}

    def create_from_schema(
        self,
        name: str,
        description: str,
        json_schema_text: str,
        prompt: str | None = None,
        summary: str | None = None,
    ) -> dict[str, Any]:
        """Create a new data model from JSON schema. Creates business views and default layout.

        Args:
            datasource: The document intelligence data source connection
            name: The name of the data model
            description: The description of the data model
            json_schema_text: The JSON schema to use to create the data model
            prompt: The prompt for the data model
            summary: (optional) The summary of the data model

        Returns:
            Response The data model

        Raises:
            DataModelServiceError: If data model already exists or creation fails
        """
        json_schema = self._context.agent_client.sanitize_json_schema(
            json.loads(json_schema_text)
        )

        original_name = name
        name = normalize_name(name)

        # Check if data model with this name already exists
        existing_model = DataModel.find_by_name(self._context.datasource, name)
        if existing_model:
            raise DataModelServiceError(
                f"Cannot create data model '{original_name}' because after normalizing special characters "
                f"it becomes '{name}', which already exists in the system."
            )

        data_model = DataModel(
            name=name,
            description=description,
            model_schema=json_schema,
            prompt=prompt,
            summary=summary,
        )

        # Generate a summary for the data model if it doesn't have one
        if not data_model.summary:
            summary = self._context.agent_client.summarize_with_args(
                {
                    "Data model name": name,
                    "Data model description": description,
                    "Data model schema": json_schema,
                }
            )
            data_model.summary = summary

        data_model.insert(self._context.datasource)

        # Create views
        try:
            self.create_business_views(name)
        except Exception as e:
            logger.error(f"Error creating views for data model {name}: {str(e)}")
            # clean up the data model
            data_model.delete(self._context.datasource)
            raise DataModelServiceError(
                f"Failed to create views for data model {name}: {str(e)}"
            ) from e

        # Create default layout using the business schema
        self._create_or_update_default_layout(name, json_schema)

        # Fetch the final data_model
        new_data_model = data_model.find_by_name(self._context.datasource, name)
        if not new_data_model:
            raise DataModelServiceError(f"Failed to create data model: {name}")

        return new_data_model.to_json()

    def create_business_views(self, data_model_name: str) -> dict[str, str]:
        """Create SQL views for a data model in the database.

        Args:
            datasource: The document intelligence data source connection
            data_model_name: The name of the data model

        Returns:
            Response with success message

        Raises:
            DataModelServiceError: If data model not found, project creation fails, or view generation fails
        """
        data_model_name = normalize_name(data_model_name)
        data_model = DataModel.find_by_name(self._context.datasource, data_model_name)
        if not data_model:
            raise DataModelServiceError(
                f"Data model with name {data_model_name} not found"
            )

        views = self._generate_views(data_model)
        views_dict = [asdict(v) for v in views]

        initialize_dataserver(PROJECT_NAME, views_dict)

        data_model.views = views_dict
        data_model.update(self._context.datasource)

        return {"Message": "Business views created successfully"}

    def _generate_views(self, data_model: DataModel) -> list[View]:
        try:
            # Transform JSON Schema to BusinessSchema format
            business_schema = transform_business_schema(data_model.model_schema)

            # Generate views
            generator = ViewGenerator(
                source_table_name="documents",
                document_column_name="translated_content",
                datasource_name=DATA_SOURCE_NAME,
                project_name=PROJECT_NAME,
            )

            return generator.generate_views(business_schema, data_model.name)
        except Exception as e:
            logger.error(f"Error generating views: {str(e)}")
            raise DataModelServiceError(f"Error generating views: {str(e)}") from e

    def _create_or_update_default_layout(
        self,
        data_model_name: str,
        business_schema: dict[str, Any],
    ) -> None:
        """Create or update the default layout for a data model.

        This method handles the creation or update of the default layout for a data model.
        The business schema is used directly as the extraction schema, and a direct mapping
        is created for the translation schema.

        Args:
            datasource: The document intelligence data source connection
            data_model_name: The name of the data model
            business_schema: The business schema to base the layout on
        """
        existing_layout = None
        data_model_name = normalize_name(data_model_name)
        existing_layout = DocumentLayout.find_by_name(
            self._context.datasource, data_model_name, DEFAULT_LAYOUT_NAME
        )

        mapping_rules = []
        for field_name in business_schema.get("properties", {}).keys():
            mapping_rules.append(
                {
                    "source": field_name,
                    "target": field_name,
                }
            )

        translation_schema = {"rules": mapping_rules}

        # Generate summary for the default layout or if existing layout has no summary
        summary = None
        if not existing_layout or not existing_layout.summary:
            summary = self._context.agent_client.summarize_with_args(
                {
                    "Layout name": DEFAULT_LAYOUT_NAME,
                    "Data model name": data_model_name,
                    "Layout schema": business_schema,
                }
            )

        if existing_layout:
            existing_layout.extraction_schema = business_schema
            existing_layout.translation_schema = translation_schema
            existing_layout.summary = summary
            existing_layout.update(self._context.datasource)
        else:
            layout = DocumentLayout(
                name=DEFAULT_LAYOUT_NAME,
                data_model=data_model_name,
                extraction_schema=business_schema,
                translation_schema=translation_schema,
                summary=summary,
            )
            layout.insert(self._context.datasource)
