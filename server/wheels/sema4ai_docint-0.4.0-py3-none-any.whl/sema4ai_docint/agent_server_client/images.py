from PIL import Image

_QUALITY = 85

def truncate_images(images: list[Image.Image], limit: int=50*1024*1024) -> list[Image.Image]:
    # Haven't figured out why, but our limit calculation seems to be off by 15% to what openai says
    limit = int(limit * 0.85)

    rolling_sum = 0
    for i, img in enumerate(images):
        rolling_sum += get_image_size_bytes(img)
        if rolling_sum > limit:
            # If we exceed the limit, return the current list, minus the current element
            return images[:i]

    return images

def get_image_size_bytes(image: Image.Image) -> int:
    """
    Approximate the size of an image, encoded as JPEG
    """
    from io import BytesIO

    buffer = BytesIO()

    # TODO a little wasteful in that `to_jpeg` is also computing this.
    image.save(buffer, format="JPEG", quality=_QUALITY)
    return len(buffer.getvalue())


def to_jpeg(img: Image.Image) -> str:
    from io import BytesIO
    from base64 import b64encode
    buffer = BytesIO()

    img.save(buffer, format="JPEG", quality=_QUALITY)
    return b64encode(buffer.getvalue()).decode("utf-8")