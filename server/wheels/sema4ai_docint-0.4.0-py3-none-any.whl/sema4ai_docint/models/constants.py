# The project name in MindsDB
PROJECT_NAME = "document_intelligence"
# Must be kept in sync with DocumentIntelligenceDataSource in data_sources.py
DATA_SOURCE_NAME = "DocumentIntelligence"
# The default layout name for a data model
DEFAULT_LAYOUT_NAME = "default"
