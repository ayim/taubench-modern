# The project name in MindsDB
PROJECT_NAME = "document_intelligence"
# Must be kept in sync with DocumentIntelligenceDataSource in data_sources.py
DATA_SOURCE_NAME = "DocumentIntelligence"
