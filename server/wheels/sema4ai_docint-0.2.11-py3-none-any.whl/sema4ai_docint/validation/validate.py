import json
import logging

from typing import List
from sema4ai.data import DataSource

from .models import ValidationResult, ValidationSummary, ValidationRule

logger = logging.getLogger(__name__)

def _generate_report(rule_statuses: List[ValidationResult]) -> ValidationSummary:
    """
    Generates a validation summary report based on rule statuses.

    Args:
        rule_statuses: List of validation results for each rule.
    Returns:
        A ValidationSummary object.
    """
    # Determine overall status
    passed_count = sum(1 for result in rule_statuses if result.status == "passed")
    failed_count = sum(1 for result in rule_statuses if result.status == "failed")
    error_count = sum(1 for result in rule_statuses if result.status == "error")
    overall_status = "passed" if failed_count == 0 and error_count == 0 else "failed"

    return ValidationSummary(
        overall_status=overall_status,
        results=rule_statuses,
        passed=passed_count,
        failed=failed_count,
        errors=error_count
    )

def validate_document_extraction(
    document_id: str, 
    data_source: DataSource,
    validation_rules: List[ValidationRule]
) -> ValidationSummary:
    """
    Validate a document based on the validation rules.
    Rules are SQL queries that are executed against the view of the document.
    
    Args:
        document_id: The ID of the document to validate
        data_source: Data source connection
        validation_rules: List of ValidationRule objects containing:
            - rule_name: Name of the validation rule
            - sql_query: SQL query to validate the document
            - rule_description: Description of what the rule validates
    
    Returns:
        A ValidationSummary object.
    """
    try:
        if not validation_rules:
            logger.warning(f"No validation rules provided for document ID: {document_id}")
            return ValidationSummary(overall_status="passed", passed=0, failed=0, errors=0, results=[])

        rule_statuses = []
        for rule in validation_rules:
            try:
                # Run the validation query
                logger.info(f"Running validation query: {rule.sql_query} with document_id: {document_id}")
                validation_result = data_source.execute_sql(rule.sql_query, params={"document_id": document_id})

                # Verify we have a result with at least one row
                if not validation_result or ((table := validation_result.to_table()) and not table or not table.rows):
                    logger.warning(f"No result from validation query: {rule.sql_query}")
                    rule_statuses.append(ValidationResult(
                        rule_name=rule.rule_name,
                        status="failed",
                        description=rule.rule_description,
                        error_message="No result from validation query",
                        sql_query=rule.sql_query,
                        context={"error": "Validation rule did not generate any rows"},
                    ))
                    continue

                result_row = table.rows[0]
                
                # The first column should be the boolean validation result
                is_valid = str(result_row[0]).lower() == 'true'

                # Collect all remaining column values as context for the caller to understand the rule execution
                context = dict(zip(table.columns[1:], result_row[1:]))
                
                if is_valid:
                    rule_statuses.append(ValidationResult(
                        rule_name=rule.rule_name,
                        status="passed",
                        description=rule.rule_description,
                        sql_query=rule.sql_query,
                        context=context,
                    ))
                else:
                    rule_statuses.append(ValidationResult(
                        rule_name=rule.rule_name,
                        status="failed",
                        description=rule.rule_description,
                        error_message="Validation query did not return true",
                        sql_query=rule.sql_query,
                        context=context,
                    ))

            except Exception as e:
                logger.error(f"Error validating rule {rule.rule_name}: {str(e)}", exc_info=True)
                rule_statuses.append(ValidationResult(
                    rule_name=rule.rule_name,
                    status="error",
                    description=rule.rule_description,
                    error_message=str(e),
                    sql_query=rule.sql_query,
                    # Give some context back to the caller
                    context={"error": f"failed to execute the query: {str(e)[:200]}"},
                ))

        # Generate report using the internal function
        summary = _generate_report(rule_statuses)
        logger.info(f"Validation summary: {summary}")
        return summary

    except Exception as e:
        logger.error(f"Error during document validation: {str(e)}")
        raise