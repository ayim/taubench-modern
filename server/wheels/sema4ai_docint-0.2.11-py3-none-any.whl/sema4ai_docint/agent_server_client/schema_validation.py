import jsonschema


def validate_json_schema(schema_dict: dict) -> tuple[bool, str]:
    """
    Validate that a dictionary is a valid JSON schema.

    Args:
        schema_dict: The dictionary to validate as a JSON schema
        
    Returns:
        tuple[bool, str]: (is_valid, error_message)
    """
    try:
        # Check if it's a valid JSON schema by trying to create a validator
        jsonschema.Draft7Validator.check_schema(schema_dict)
        return True, ""
    except jsonschema.SchemaError as e:
        return False, f"Invalid JSON schema: {str(e)}"
    except Exception as e:
        return False, f"Schema validation error: {str(e)}" 