import json
import re
from typing import Any
import jsonschema


def normalize_name(name: str) -> str:
    """Normalize name by removing special characters, replacing spaces with underscores,
    and converting to lowercase.

    Args:
        name: The name to normalize

    Returns:
        The normalized name
    """
    # Remove special characters (keep only alphanumerics and spaces)
    cleaned = re.sub(r"[^\w\s]", "", name.strip())

    # Replace spaces with underscores and convert to lowercase
    return "_".join(cleaned.split()).lower()


def validate_schema(json_schema: str) -> dict[str, Any]:
    """Validates a JSON schema.

    Args:
        json_schema: The JSON schema to validate

    Returns:
        The parsed schema

    Raises:
        Exception: If the schema is invalid
    """
    parsed_schema = json.loads(json_schema)
    # TODO Reducto's extraction schema is a subset of JSONschema, be more specific.
    jsonschema.validators.validator_for(parsed_schema)
    return parsed_schema

