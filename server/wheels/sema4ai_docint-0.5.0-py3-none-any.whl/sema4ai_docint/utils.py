import json
import re
from typing import Any


def normalize_name(name: str) -> str:
    """Normalize name by removing special characters, replacing spaces with underscores,
    and converting to lowercase.

    Args:
        name: The name to normalize

    Returns:
        The normalized name
    """
    # Remove special characters (keep only alphanumerics and spaces)
    cleaned = re.sub(r"[^\w\s]", "", name.strip())

    # Replace spaces with underscores and convert to lowercase
    return "_".join(cleaned.split()).lower()


# TODO: This method is being used for data model validation as well. Currently, extraction
# schemas and data model schemas are the same, but they may become separate, at which point
# we need to support both validation concerns.
def validate_extraction_schema(json_schema: str | dict[str, Any]) -> dict[str, Any]:
    """Validates a JSON schema for use with Reducto as an extraction schema.

    Args:
        json_schema: The JSON schema to validate

    Returns:
        The parsed schema

    Raises:
        Exception: If the schema is invalid or not compatible with Reducto
    """
    from jsonschema.validators import validator_for

    if isinstance(json_schema, str):
        parsed_schema = json.loads(json_schema)
    else:
        parsed_schema = json_schema

    # Get the appropriate validator for this schema (note that usually we won't get a schema
    # with a $schema keyword, so we will likely be using the default validator)
    # TODO: Reducto's extraction schema is a subset of JSONschema, be more specific.
    validator_class = validator_for(parsed_schema)
    validator = validator_class(parsed_schema)

    # Validate that the schema itself is valid according to JSON Schema specification
    validator.check_schema(parsed_schema)

    # Reducto requires schemas to be of type "object"
    schema_type = parsed_schema.get("type")
    if schema_type != "object":
        raise ValueError(f"Schema must be of type 'object', got type '{schema_type}'")
    properties = parsed_schema.get("properties")
    if properties is None or not isinstance(properties, dict):
        raise ValueError(
            "Schema must have a non-null 'properties' field of type 'object'"
        )

    return parsed_schema
