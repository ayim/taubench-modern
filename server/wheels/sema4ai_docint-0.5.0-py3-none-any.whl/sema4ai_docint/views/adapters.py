"""
Database adapters for generating SQL views for different database systems.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

from .type_system import StandardTypes


class DBAdapter(ABC):
    """
    Abstract base class for database adapters.
    Each adapter handles database-specific SQL generation and type casting.
    """

    @abstractmethod
    def build_json_path(self, component: str, is_last: bool, current_path: str) -> str:
        """
        Build a JSON path expression for the given component.

        Args:
            component: The component name
            is_last: Whether this is the last component in the path
            current_path: The current path expression

        Returns:
            A database-specific JSON path expression
        """
        pass

    @abstractmethod
    def build_array_accessor(self, current_path: str, component: str) -> str:
        """
        Build an array accessor expression.

        Args:
            current_path: The current path expression
            component: The array component name

        Returns:
            A database-specific array accessor expression
        """
        pass

    @abstractmethod
    def build_lateral_join(self, array_path: str, alias: str) -> str:
        """
        Build a LATERAL join expression for array elements.

        Args:
            array_path: The path to the array
            alias: The alias for array elements

        Returns:
            A database-specific LATERAL join expression
        """
        pass

    @abstractmethod
    def apply_type_cast(
        self,
        json_path: str,
        field_type: str,
        attributes: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Apply type casting to a JSON path expression.

        Args:
            json_path: The JSON path expression
            field_type: The abstract field type (string, number, integer, boolean, date, datetime)
            attributes: Optional type attributes (precision, scale, etc.)

        Returns:
            A database-specific type-cast expression
        """
        pass

    def parse_type(
        self, field_type: str, attributes: Optional[Dict[str, Any]] = None
    ) -> tuple[StandardTypes, str]:
        """
        Parse a field type from the abstract type system into a database-specific type.
        BusinessSchema dataclass validation handles any unsupported field type upstream.

        Args:
            field_type: The field type from the abstract type system (already validated by DataFormat)
            attributes: Additional type attributes

        Returns:
            A database-specific type string
        """
        # Convert to lowercase for case-insensitive comparison
        field_type_lower = field_type.lower()

        if field_type_lower == StandardTypes.STRING:
            if attributes and "length" in attributes:
                length = attributes["length"]
                return StandardTypes.STRING, f"VARCHAR({length})"
            return StandardTypes.STRING, "VARCHAR"

        elif field_type_lower == StandardTypes.NUMBER:
            if attributes and "precision" in attributes and "scale" in attributes:
                precision = attributes["precision"]
                scale = attributes["scale"]
                return StandardTypes.NUMBER, f"DECIMAL({precision},{scale})"
            elif attributes and "precision" in attributes:
                precision = attributes["precision"]
                return StandardTypes.NUMBER, f"DECIMAL({precision})"
            return StandardTypes.NUMBER, "DECIMAL"

        elif field_type_lower == StandardTypes.INTEGER:
            return StandardTypes.INTEGER, "INT"

        elif field_type_lower == StandardTypes.BOOLEAN:
            return StandardTypes.BOOLEAN, "BOOLEAN"

        elif field_type_lower == StandardTypes.DATE:
            return StandardTypes.DATE, "DATE"

        elif field_type_lower == StandardTypes.DATETIME:
            return StandardTypes.DATETIME, "TIMESTAMP"

        raise ValueError(f"Unsupported field type: {field_type}")


class PostgresAdapter(DBAdapter):
    """
    Adapter for PostgreSQL database.
    """

    def build_json_path(self, component: str, is_last: bool, current_path: str) -> str:
        """
        Build a PostgreSQL JSON path expression.
        Uses -> for object access and ->> for text extraction (last component).
        """
        if is_last:
            return f"{current_path}->>'{component}'"
        else:
            return f"{current_path}->'{component}'"

    def build_array_accessor(self, current_path: str, component: str) -> str:
        """
        Build a PostgreSQL array accessor expression.
        """
        return f"{current_path}->'{component}'"

    def build_lateral_join(self, array_path: str, alias: str) -> str:
        """
        Build a PostgreSQL LATERAL join expression.
        """
        return f"LATERAL jsonb_array_elements({array_path}) AS {alias}"

    def apply_type_cast(
        self,
        json_path: str,
        field_type: str,
        attributes: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Apply PostgreSQL type casting to a JSON path expression.
        Uses standard CAST syntax rather than Postgres-specific :: syntax.

        Example:
            apply_type_cast("doc->>'price'", "number", {"precision": 10, "scale": 2}) ->
            "CAST(doc->>'price' AS DECIMAL(10,2))"
        """
        db_type, db_type_str = self.parse_type(field_type, attributes)

        if db_type == StandardTypes.NUMBER:
            if attributes and "precision" in attributes:
                try:
                    precision = int(attributes["precision"])
                    scale = 0
                    if "scale" in attributes:
                        scale = int(attributes["scale"])

                    format_str = PostgresAdapter._make_format_str(precision, scale)
                except ValueError:
                    # we got some kind of bogus precision or scale value
                    pass
            else:
                # Default to a large value with 2 decimal places
                format_str = PostgresAdapter._make_format_str(18, 2)

            return f"TO_NUMBER({json_path}, '{format_str}')"
        elif db_type == StandardTypes.INTEGER:
            format_str = PostgresAdapter._make_format_str(18, 0)
            return f"TO_NUMBER({json_path}, '{format_str}')"
        else:
            return f"CAST({json_path} AS {db_type_str})"

    @classmethod
    def _make_format_str(cls, precision: int, scale: int) -> str:
        """
        Make a format string for a number with the given precision and scale.
        Groups digits from right to left with commas (G) every 3 digits.

        Args:
            precision: Total number of digits
            scale: Number of decimal places

        Returns:
            Format string for TO_NUMBER function with proper grouping
        """
        left_digits = precision - scale

        # Build format string starting with sign
        format_str = "S"

        # Handle the case where we only have decimal places
        if left_digits <= 0:
            format_str += "D" + "9" * scale
            return format_str

        # Work from right to left for the whole number part
        remaining = left_digits
        groups: list[str] = []

        while remaining > 0:
            # Take up to 3 digits for this group
            group_size = min(3, remaining)
            groups.insert(0, "9" * group_size)
            remaining -= group_size

        # Join groups with G (comma) separator
        format_str += "G".join(groups)

        # Add decimal places if scale > 0
        if scale > 0:
            format_str += "D" + "9" * scale

        return format_str
