from __future__ import annotations

import json
import tempfile
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any, Iterable, List, Union

import wasmtime


JsonLike = Any


@dataclass
class JaqResult:
    """Represents the outcome of running a jaq filter."""

    output: List[JsonLike]


class JaqRuntime:
    """Execute jaq filters inside a WASI-enabled WebAssembly runtime."""

    def __init__(self, wasm_module_path: Union[str, Path, None] = None) -> None:
        self._engine = wasmtime.Engine()
        self._module = self._load_module(wasm_module_path)
        self._linker = wasmtime.Linker(self._engine)
        self._linker.define_wasi()

    def _load_module(self, path: Union[str, Path, None]) -> wasmtime.Module:
        if path is not None:
            return wasmtime.Module.from_file(self._engine, str(Path(path)))

        resource = resources.files(__package__).joinpath("data/jaq.wasm")
        with resources.as_file(resource) as wasm_path:
            return wasmtime.Module.from_file(self._engine, str(wasm_path))

    def run(self, filter_src: str, inputs: Iterable[JsonLike] | None = None) -> JaqResult:
        """Run ``filter_src`` against ``inputs`` and return the decoded JSON output."""

        json_stream = self._encode_inputs(inputs)

        with tempfile.TemporaryDirectory() as tmp:
            tempdir = Path(tmp)
            stdin_path = tempdir / "input.jsonl"
            stdout_path = tempdir / "output.jsonl"

            stdin_path.write_text(json_stream, encoding="utf-8")

            wasi = wasmtime.WasiConfig()
            wasi.argv = ["jaq-wasi", filter_src]
            wasi.stdin_file = str(stdin_path)
            wasi.stdout_file = str(stdout_path)
            wasi.inherit_stderr()

            store = wasmtime.Store(self._engine)
            store.set_wasi(wasi)

            instance = self._linker.instantiate(store, self._module)
            start = instance.exports(store)["_start"]
            start(store)

            output = stdout_path.read_text(encoding="utf-8")

        results = [json.loads(line) for line in output.splitlines() if line.strip()]
        return JaqResult(results)

    @staticmethod
    def _encode_inputs(inputs: Iterable[JsonLike] | None) -> str:
        if inputs is None:
            return ""

        if isinstance(inputs, (str, bytes)):
            raise TypeError("inputs must be an iterable of JSON-serialisable Python objects")

        buffer = []
        for value in inputs:
            buffer.append(json.dumps(value))
        return "\n".join(buffer)


_default_runtime: JaqRuntime | None = None


def run_filter(filter_src: str, inputs: Iterable[JsonLike] | None = None) -> List[JsonLike]:
    """Run ``filter_src`` with a shared runtime and return the resulting values."""

    global _default_runtime
    if _default_runtime is None:
        _default_runtime = JaqRuntime()
    return _default_runtime.run(filter_src, inputs).output


__all__ = ["JaqRuntime", "JaqResult", "run_filter"]
