# Change Log

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/)
and this project adheres to [Semantic Versioning](https://semver.org/).

## [1.3.3] - 2025-08-26

### Added

- Enhanced `download_file` action to automatically attach downloaded files to chat
- Files are now automatically available in the conversation after download for further processing

## [1.3.2] - 2025-08-07

### Changed

- Update sema4ai-actions to `1.4.1` version

## [1.3.1] - 2025-06-18

- Updated sema4ai-actions version carrying a new version of pydantic

## [1.3.0] - 2025-04-15

### Changed

- Use `sema4ai-http-helper` to make HTTP requests which now supports certificates and proxies

## [1.2.2] - 2025-04-04

### Changed

- Dependency versions updated

## [1.2.1] - 2025-03-26

### Changed

- Changed the test data to use Sema4ai websites

## [1.2.0] - 2025-03-24

### Added

- External endpoint definition added to package.yaml [Read more](https://sema4.ai/docs/team-edition/marketplace/snowflake-admin#managing-external-access)

## [1.1.2] - 2025-03-06

### Changed

- Dependency versions updated
- Use `Response[T]` as return type to actions

## [1.1.1] - 2025-01-09

### Changed

- Dependency versions updated

### Fixed

- Return type for `fill_elements` action

## [1.1.0] - 2024-11-18

### Added

- Improved text content cleanup for all 'text' properties

### Fixed

- Fix how parameter 'user_agent' is handled for 'get_website_content' action
- Set max timeout 5 seconds for waiting for 'networkidle', but continue actions regardless

## [1.0.2] - 2024-10-03

### Changed

- Dependency versions updated

## [1.0.1] - 2024-07-31

Description changed.

### Added

### Changed

- Improved the description of the package in `package.yaml`

### Fixed

### Removed

## [1.0.0] - 2024-07-04

First version published, changelog tracking starts.

### Added

- Download file
- Fill form elements
- Get website content

### Changed

### Fixed

### Removed
