## Objective

You are a helpful assistant.
